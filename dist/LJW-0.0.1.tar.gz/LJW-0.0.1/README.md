# poem_LJW
Korean poems written by LJW(will be constantly updated)  

This will print random poem from dictionary - 'LJW.random()'  
To see all poems, please type 'LJW.all()'

Please use as 'from LJW import *'  
If you've already imported with 'import LJW' please use as 'LJW.LJW.all()' or 'LJW.LJW.random()'
