# poem_LJW
Korean poems written by LJW(will be constantly updated)  
This will only work above python 3.7!

This will print random poem from dictionary - 'LJW.random()'  
To see all poems, please type 'LJW.everything()'  

Please use as 'from LJW import *'  
If you've already imported with 'import LJW' please use as 'LJW.LJW.all()' or 'LJW.LJW.random()'

-----1.0.0 Update-----  
You can just use 'import LJW' and 'LJW.random()' or 'LJW.everything()'  
